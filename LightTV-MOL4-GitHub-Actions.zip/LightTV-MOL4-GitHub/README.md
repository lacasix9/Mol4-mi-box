# LightTV MOL4 - Clone 100% MyTVOnline4 pour Mi Box S

Clone exact de MyTVOnline4 Formuler pour Mi Box S Android TV 9 avec logo lion doré.

## Installation automatique via GitHub Actions

1. Va dans onglet Actions de ce repo GitHub
2. Clique sur dernier workflow Build LightTV MOL4 APK
3. Télécharge artifact LightTV-MOL4-Debug-APK-MiBoxS
4. Tu as ton app-debug.apk prêt !

Ou va dans Releases -> télécharge la dernière release.

## Installation sur Mi Box S

**Downloader (sans PC):**
1. Sur Mi Box S, installe Downloader depuis Play Store
2. Entre l'URL directe de l'APK GitHub
3. Installe

**Clé USB:**
Copie app-debug.apk sur clé USB -> File Manager -> installe

**ADB:**
adb connect 192.168.1.XX
adb install app-debug.apk

## Fonctionnalités 100% MOL4
- LIVE TV 3 panneaux Groups | Channels | Preview comme Z11
- VOD Grille 5 colonnes
- SERIES Recherche par saison [SAISON 1][SAISON 2] -> E01 E02
- EPG Timeline XMLTV
- Sous-titres SRT/VTT + MKV
- Sauvegarde playlist + mise à jour auto au démarrage
- Logo lion doré
- 100% télécommande Mi Box S

Premier lancement: entre portail Xtream ou M3U + XMLTV optionnel
