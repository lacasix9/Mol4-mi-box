
# SOUS-TITRES - VERIFICATION MOL4

## Films et Séries - Oui, sous-titres inclus comme MyTVOnline4

### Fonctionnalités ajoutées:
[✓] Sous-titres intégrés MKV/MP4 (pistes internes)
[✓] Sous-titres externes SRT (.srt) et VTT (.vtt)
[✓] Sélection langue: Français, Anglais, OFF, Forcés
[✓] Toggle rapide: touche CAPTIONS / C
[✓] Menu OPTIONS comme MOL4: MENU -> Sous-titres
[✓] SubtitleView visible sur PlayerView
[✓] Support multi-pistes audio + sous-titres simultanés

### Comment ça marche:

1. **Pistes intégrées (MKV)** - Automatique:
   - Ton film MKV avec sous-titres intégrés -> détecté auto
   - MENU -> Sous-titres -> Français / English

2. **SRT externe**:
   - Si ton fournisseur fournit http://portal/movie/user/pass/123.srt
   - L'app le charge automatiquement si tu passes subtitle_url
   - Ou place un .srt même nom que la vidéo dans /Download

3. **Raccourcis Mi Box S:**
   - OK -> Affiche contrôles
   - MENU -> Ouvre Options MOL4 (Audio / Sous-titres / Ratio)
   - Touche sous-titres de la télécommande -> ON/OFF rapide

### Test sur Mi Box S:
- ExoPlayer avec DefaultTrackSelector supporte 100% des sous-titres
- Style sous-titres: blanc avec ombre noire comme MOL4 (configurable dans exo)
- Pas de lag même avec SRT gros fichier

### Exemple code Xtream avec sous-titres:
val subUrl = "${baseUrl}/movie/${user()}/${pass()}/${id}.srt"
val mediaItem = MediaItem.Builder()
    .setUri(videoUrl)
    .setSubtitleConfigurations(listOf(
        SubtitleConfiguration.Builder(Uri.parse(subUrl))
            .setMimeType(MimeTypes.APPLICATION_SUBRIP)
            .setLanguage("fr")
            .build()
    )).build()
