package com.lighttv.mol4
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class SeriesDetailActivity : FragmentActivity() {
    private var currentSeason = 1
    private lateinit var series: SeriesItem

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_series_detail)
        val seriesId = intent.getStringExtra("series_id") ?: "1"
        val seriesName = intent.getStringExtra("series_name") ?: "Série"

        findViewById<TextView>(R.id.tv_series_title).text = seriesName

        val rvSeasons = findViewById<RecyclerView>(R.id.rv_seasons)
        val rvEpisodes = findViewById<RecyclerView>(R.id.rv_episodes)
        val tvSeasonInfo = findViewById<TextView>(R.id.tv_season_info)

        rvSeasons.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvEpisodes.layoutManager = LinearLayoutManager(this)

        Thread {
            val manager = XtreamFullManager(getSharedPreferences("lighttv",0))
            series = manager.getSeriesInfo(seriesId)
            runOnUiThread {
                tvSeasonInfo.text = "${series.seasons.size} saisons - ${series.seasons.sumOf { it.episodes.size }} épisodes"
                
                // Saisons - comme MOL4 avec boutons Saison 1, Saison 2...
                rvSeasons.adapter = SeasonAdapter(series.seasons, currentSeason) { seasonNum ->
                    currentSeason = seasonNum
                    (rvSeasons.adapter as SeasonAdapter).selected = seasonNum
                    rvSeasons.adapter?.notifyDataSetChanged()
                    val season = series.seasons.find { it.num == seasonNum }
                    rvEpisodes.adapter = EpisodeAdapter(season?.episodes ?: emptyList()) { ep ->
                        startActivity(Intent(this, PlayerActivity::class.java).apply{
                            putExtra("url", ep.streamUrl)
                            putExtra("name", "${series.name} - S${ep.season}E${ep.episode} ${ep.title}")
                        })
                    }
                }

                // Charge saison 1 par défaut
                val firstSeason = series.seasons.firstOrNull()
                if(firstSeason != null){
                    currentSeason = firstSeason.num
                    rvEpisodes.adapter = EpisodeAdapter(firstSeason.episodes) { ep ->
                        startActivity(Intent(this, PlayerActivity::class.java).apply{
                            putExtra("url", ep.streamUrl)
                            putExtra("name", "${series.name} - S${ep.season}E${ep.episode}")
                        })
                    }
                }
            }
        }.start()
    }

    class SeasonAdapter(private val seasons: List<Season>, var selected:Int, val onClick:(Int)->Unit): RecyclerView.Adapter<SeasonAdapter.VH>(){
        class VH(v:android.view.View): RecyclerView.ViewHolder(v){ val btn=v as Button }
        override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{
            val btn = Button(p.context).apply{
                layoutParams = ViewGroup.MarginLayoutParams(180, 80).apply{ setMargins(8,0,8,0) }
                isFocusable=true
            }
            return VH(btn)
        }
        override fun onBindViewHolder(h:VH, pos:Int){
            val s=seasons[pos]
            h.btn.text = "SAISON ${s.num}"
            h.btn.setBackgroundColor(if(s.num==selected) 0xFF00A6ED.toInt() else 0xFF1E1E26.toInt())
            h.btn.setTextColor(0xFFFFFFFF.toInt())
            h.btn.setOnClickListener { onClick(s.num) }
            h.btn.setOnFocusChangeListener { v,hasFocus ->
                if(hasFocus) onClick(s.num)
                v.scaleX = if(hasFocus) 1.1f else 1f
                v.scaleY = if(hasFocus) 1.1f else 1f
            }
        }
        override fun getItemCount()=seasons.size
    }

    class EpisodeAdapter(private val episodes: List<Episode>, val onPlay:(Episode)->Unit): RecyclerView.Adapter<EpisodeAdapter.VH>(){
        class VH(v:android.view.View): RecyclerView.ViewHolder(v){
            val tvTitle=v.findViewById<TextView>(R.id.tv_ep_title)
            val tvNum=v.findViewById<TextView>(R.id.tv_ep_num)
        }
        override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{
            val v=LayoutInflater.from(p.context).inflate(R.layout.item_episode_mol4,p,false)
            v.isFocusable=true
            return VH(v)
        }
        override fun onBindViewHolder(h:VH, pos:Int){
            val ep=episodes[pos]
            h.tvTitle.text = ep.title
            h.tvNum.text = "E${ep.episode.toString().padStart(2,'0')}"
            h.itemView.setBackgroundResource(R.drawable.bg_channel_normal)
            h.itemView.setOnFocusChangeListener { v,hasFocus ->
                v.setBackgroundResource(if(hasFocus) R.drawable.bg_channel_selected else R.drawable.bg_channel_normal)
            }
            h.itemView.setOnClickListener { onPlay(ep) }
        }
        override fun getItemCount()=episodes.size
    }
}