
package com.lighttv.mol4
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.core.content.edit
import androidx.fragment.app.FragmentActivity
class SetupActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)
        val prefs=getSharedPreferences("lighttv", MODE_PRIVATE)
        val etUrl=findViewById<EditText>(R.id.et_portal)
        val etUser=findViewById<EditText>(R.id.et_user)
        val etPass=findViewById<EditText>(R.id.et_pass)
        val etM3u=findViewById<EditText>(R.id.et_m3u)
        val etXmltv=findViewById<EditText>(R.id.et_xmltv)
        etUrl.setText(prefs.getString("portal_url","")); etUser.setText(prefs.getString("username","")); etPass.setText(prefs.getString("password","")); etM3u.setText(prefs.getString("m3u_url","")); etXmltv.setText(prefs.getString("xmltv_url",""))
        findViewById<Button>(R.id.btn_save).setOnClickListener{
            prefs.edit{ putString("portal_url", etUrl.text.toString().trim()); putString("username", etUser.text.toString().trim()); putString("password", etPass.text.toString().trim()); putString("m3u_url", etM3u.text.toString().trim()); putString("xmltv_url", etXmltv.text.toString().trim()); putString("portal_name","My Portal MOL4") }
            finish(); startActivity(intent.apply{ setClass(this@SetupActivity, MainActivity::class.java) })
        }
    }
}
