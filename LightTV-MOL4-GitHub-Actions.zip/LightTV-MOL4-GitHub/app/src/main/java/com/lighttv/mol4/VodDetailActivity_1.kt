package com.lighttv.mol4
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
class VodDetailActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vod_detail)
        val name=intent.getStringExtra("name") ?: ""; val url=intent.getStringExtra("url") ?: ""; val plot=intent.getStringExtra("plot") ?: ""
        findViewById<TextView>(R.id.tv_detail_title).text=name
        findViewById<TextView>(R.id.tv_detail_plot).text=plot
        findViewById<Button>(R.id.btn_play_vod).setOnClickListener{
            startActivity(Intent(this, PlayerActivity::class.java).apply{ putExtra("url", url); putExtra("name", name) })
        }
    }
}