package com.lighttv.mol4
data class Channel(val id:String, val num:Int, val name:String, val logo:String, val group:String, val streamUrl:String, val epgNow:String="", val epgNext:String="", val epgProgress:Int=0, val isFav:Boolean=false, val isHD:Boolean=true)
data class Group(val name:String, val count:Int)
data class VodItem(val id:String, val name:String, val poster:String, val rating:String, val year:String, val genre:String, val streamUrl:String, val plot:String="")
data class SeriesItem(val id:String, val name:String, val poster:String, val seasons: List<Season>)
data class Season(val num:Int, val episodes: List<Episode>)
data class Episode(val id:String, val title:String, val season:Int, val episode:Int, val streamUrl:String)
data class EpgEvent(val title:String, val start:Long, val end:Long, val desc:String, val channelId:String)
enum class MenuItemMOL4 { LIVE, VOD, SERIES, RADIO, EPG, RECORDINGS, SETTINGS, SEARCH }