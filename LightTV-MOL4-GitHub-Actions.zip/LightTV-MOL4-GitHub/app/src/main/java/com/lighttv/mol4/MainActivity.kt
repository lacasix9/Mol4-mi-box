package com.lighttv.mol4
import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {
    private val menuItems = listOf(
        MenuItemMOL4.LIVE to "LIVE TV",
        MenuItemMOL4.VOD to "MOVIES",
        MenuItemMOL4.SERIES to "SERIES",
        MenuItemMOL4.EPG to "TV GUIDE",
        MenuItemMOL4.SETTINGS to "SETTINGS"
    )
    private var selectedMenu = 0
    private lateinit var cacheManager: PlaylistCacheManager
    private lateinit var xtreamManager: XtreamFullManager
    private lateinit var autoUpdateManager: AutoUpdateManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_mol4)
        val prefs = getSharedPreferences("lighttv", MODE_PRIVATE)
        
        if ((prefs.getString("portal_url","") ?: "").isEmpty() && (prefs.getString("m3u_url","") ?: "").isEmpty()) {
            startActivity(Intent(this, SetupActivity::class.java)); finish(); return
        }

        cacheManager = PlaylistCacheManager(this, prefs)
        xtreamManager = XtreamFullManager(prefs)
        autoUpdateManager = AutoUpdateManager(this, prefs, xtreamManager, cacheManager)

        renderMenu()
        
        // VERIFICATION: Sauvegarde playlist + mise à jour auto comme MyTVOnline4
        val tvStatus = findViewById<TextView>(R.id.tv_update_status)
        tvStatus.text = if(cacheManager.hasCache()) "Cache: ${cacheManager.loadLiveChannels().size} chaînes - Mise à jour..." else "Premier démarrage - Chargement..."
        
        autoUpdateManager.performStartupUpdate(
            onProgress = { msg -> runOnUiThread { tvStatus.text = msg } },
            onComplete = { success ->
                runOnUiThread {
                    tvStatus.text = if(success) "✓ Playlist à jour - ${cacheManager.loadLiveChannels().size} chaînes" else "Cache utilisé"
                    loadFragment(LiveTvFragment(), 0)
                }
            }
        )

        // Si cache existe, charge direct pour démarrage instantané comme MOL4
        if(cacheManager.hasCache()){
            loadFragment(LiveTvFragment(), 0)
        }

        findViewById<TextView>(R.id.tv_portal_name).text = prefs.getString("portal_name","Portal") ?: "Portal"
        findViewById<LinearLayout>(R.id.menu_container).post {
            findViewById<LinearLayout>(R.id.menu_container).getChildAt(0)?.requestFocus()
        }
    }

    private fun renderMenu() {
        val container = findViewById<LinearLayout>(R.id.menu_container)
        container.removeAllViews()
        menuItems.forEachIndexed { idx, (type, label) ->
            val view = layoutInflater.inflate(R.layout.item_menu_mol4, container, false)
            val tv = view.findViewById<TextView>(R.id.tv_menu)
            tv.text = label
            view.isFocusable = true
            view.isFocusableInTouchMode = true
            view.isSelected = idx==selectedMenu
            tv.setTextColor(if(idx==selectedMenu) 0xFFFFFFFF.toInt() else 0xFF8A8A9E.toInt())
            view.setBackgroundResource(if(idx==selectedMenu) R.drawable.bg_menu_selected else 0)
            view.setOnFocusChangeListener { _, hasFocus -> if(hasFocus){ selectedMenu=idx; renderMenu() } }
            view.setOnClickListener {
                selectedMenu=idx; renderMenu()
                when(type){
                    MenuItemMOL4.LIVE -> loadFragment(LiveTvFragment(), idx)
                    MenuItemMOL4.VOD -> loadFragment(VodFragment(), idx)
                    MenuItemMOL4.SERIES -> loadFragment(SeriesFragment(), idx)
                    MenuItemMOL4.EPG -> loadFragment(EpgGuideFragment(), idx)
                    MenuItemMOL4.SETTINGS -> loadFragment(SettingsFragment(), idx)
                    else -> loadFragment(LiveTvFragment(), idx)
                }
            }
            container.addView(view)
        }
    }

    private fun loadFragment(f: Fragment, menuIdx:Int) {
        selectedMenu = menuIdx
        supportFragmentManager.beginTransaction().replace(R.id.content_container, f).commit()
    }
}