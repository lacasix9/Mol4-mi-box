package com.lighttv.mol4
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.ui.PlayerView

class LiveTvFragment : Fragment() {
    private lateinit var manager: XtreamFullManager
    private lateinit var cacheManager: PlaylistCacheManager
    private var allChannels: List<Channel> = emptyList()
    private var groups: List<Group> = emptyList()
    private var filteredChannels: List<Channel> = emptyList()
    private var selectedGroup = 0
    private var selectedChannel = 0
    private var player: ExoPlayer? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_live_mol4, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val prefs = requireContext().getSharedPreferences("lighttv",0)
        manager = XtreamFullManager(prefs)
        cacheManager = PlaylistCacheManager(requireContext(), prefs)
        
        val rvGroups = view.findViewById<RecyclerView>(R.id.rv_groups)
        val rvChannels = view.findViewById<RecyclerView>(R.id.rv_channels)
        val tvPreviewName = view.findViewById<TextView>(R.id.tv_preview_name)
        val tvPreviewEpg = view.findViewById<TextView>(R.id.tv_preview_epg)
        val playerView = view.findViewById<PlayerView>(R.id.preview_player)
        val tvCount = view.findViewById<TextView>(R.id.tv_channels_count)

        // 1. Chargement instantané depuis cache comme MyTVOnline4 (pas d'attente)
        val cachedChannels = cacheManager.loadLiveChannels()
        val cachedGroups = cacheManager.loadGroups()
        
        if(cachedChannels.isNotEmpty()){
            allChannels = cachedChannels
            groups = if(cachedGroups.isNotEmpty()) cachedGroups else cachedChannels.groupBy { it.group }.map { Group(it.key, it.value.size) }
            filteredChannels = allChannels
            tvCount.text = "${filteredChannels.size} chaînes (cache)"
            setupAdapters(rvGroups, rvChannels, tvPreviewName, tvPreviewEpg, playerView, tvCount)
        }

        // 2. Mise à jour en arrière-plan comme MOL4
        Thread {
            val freshGroups = manager.getLiveGroups()
            val freshChannels = manager.getLiveChannels()
            if(freshChannels.isNotEmpty()){
                activity?.runOnUiThread {
                    // Sauvegarde auto comme MOL4
                    cacheManager.saveLiveChannels(freshChannels)
                    cacheManager.saveGroups(freshGroups)
                    
                    if(cachedChannels.isEmpty()){
                        allChannels = freshChannels
                        groups = freshGroups
                        filteredChannels = allChannels
                        setupAdapters(rvGroups, rvChannels, tvPreviewName, tvPreviewEpg, playerView, tvCount)
                    } else {
                        // Mise à jour silencieuse si nouvelles chaînes
                        if(freshChannels.size != cachedChannels.size){
                            allChannels = freshChannels
                            groups = freshGroups
                            filteredChannels = allChannels
                            (rvGroups.adapter as? GroupAdapter)?.let { 
                                // Update groups
                            }
                            (rvChannels.adapter as? ChannelAdapter)?.update(filteredChannels)
                            tvCount.text = "${filteredChannels.size} chaînes (mis à jour)"
                        }
                    }
                }
            }
        }.start()
    }

    private fun setupAdapters(rvGroups: RecyclerView, rvChannels: RecyclerView, tvName: TextView, tvEpg: TextView, playerView: PlayerView, tvCount: TextView){
        rvGroups.layoutManager = LinearLayoutManager(context)
        rvGroups.adapter = GroupAdapter(groups, selectedGroup) { idx ->
            selectedGroup = idx; selectedChannel=0
            (rvGroups.adapter as GroupAdapter).selected = idx
            rvGroups.adapter?.notifyDataSetChanged()
            filteredChannels = if(idx==0) allChannels else allChannels.filter { it.group==groups[idx].name || groups[idx].name=="All" }
            tvCount.text = "${filteredChannels.size} chaînes"
            (rvChannels.adapter as? ChannelAdapter)?.update(filteredChannels)
            updatePreview(filteredChannels.getOrNull(0), tvName, tvEpg, playerView)
        }

        rvChannels.layoutManager = LinearLayoutManager(context)
        rvChannels.adapter = ChannelAdapter(filteredChannels, selectedChannel, 
            onFocus = { idx, ch -> selectedChannel=idx; updatePreview(ch, tvName, tvEpg, playerView) },
            onPlay = { ch -> startActivity(Intent(context, PlayerActivity::class.java).apply { putExtra("url", ch.streamUrl); putExtra("name", ch.name) }) }
        )
        updatePreview(filteredChannels.firstOrNull(), tvName, tvEpg, playerView)
    }

    private fun updatePreview(ch: Channel?, nameView: TextView, epgView: TextView, playerView: PlayerView) {
        if(ch==null) return
        nameView.text = "${ch.num.toString().padStart(3,'0')}  ${ch.name}"
        epgView.text = "${ch.epgNow} | ${ch.epgNext}  [${ch.epgProgress}%]"
        player?.release()
        player = ExoPlayer.Builder(requireContext()).build().also {
            playerView.player = it
            try { it.setMediaItem(MediaItem.fromUri(ch.streamUrl)); it.prepare(); it.playWhenReady=true } catch(e:Exception){}
        }
    }

    override fun onDestroyView() { super.onDestroyView(); player?.release(); player=null }

    class GroupAdapter(private val groups: List<Group>, var selected:Int, val onClick:(Int)->Unit): RecyclerView.Adapter<GroupAdapter.VH>() {
        class VH(v:View): RecyclerView.ViewHolder(v){ val tv= v.findViewById<TextView>(R.id.tv_group_name); val tvCount=v.findViewById<TextView>(R.id.tv_group_count) }
        override fun onCreateViewHolder(p:ViewGroup, t:Int):VH { val v=LayoutInflater.from(p.context).inflate(R.layout.item_group_mol4,p,false); v.isFocusable=true; return VH(v) }
        override fun onBindViewHolder(h:VH, pos:Int){ val g=groups[pos]; h.tv.text=g.name; h.tvCount.text=g.count.toString(); h.itemView.isSelected=pos==selected; h.itemView.setBackgroundResource(if(pos==selected) R.drawable.bg_group_selected else 0); h.tv.setTextColor(if(pos==selected) 0xFFFFFFFF.toInt() else 0xFF8A8A9E.toInt()); h.itemView.setOnClickListener { onClick(pos) }; h.itemView.setOnFocusChangeListener { _,hasFocus -> if(hasFocus) onClick(pos) } }
        override fun getItemCount()=groups.size
    }
    class ChannelAdapter(private var channels: List<Channel>, var selected:Int, val onFocus:(Int,Channel)->Unit, val onPlay:(Channel)->Unit): RecyclerView.Adapter<ChannelAdapter.VH>() {
        class VH(v:View): RecyclerView.ViewHolder(v){ val tvNum=v.findViewById<TextView>(R.id.tv_ch_num); val tvName=v.findViewById<TextView>(R.id.tv_ch_name); val tvEpg=v.findViewById<TextView>(R.id.tv_ch_epg); val progress=v.findViewById<View>(R.id.progress_epg) }
        fun update(newList:List<Channel>){ channels=newList; notifyDataSetChanged() }
        override fun onCreateViewHolder(p:ViewGroup, t:Int):VH { val v=LayoutInflater.from(p.context).inflate(R.layout.item_channel_mol4,p,false); v.isFocusable=true; return VH(v) }
        override fun onBindViewHolder(h:VH, pos:Int){ val c=channels[pos]; h.tvNum.text=c.num.toString().padStart(3,'0'); h.tvName.text=c.name; h.tvEpg.text=c.epgNow; h.itemView.setBackgroundResource(if(pos==selected) R.drawable.bg_channel_selected else R.drawable.bg_channel_normal); h.itemView.setOnFocusChangeListener { _,hasFocus -> if(hasFocus){ selected=pos; onFocus(pos,c) } }; h.itemView.setOnClickListener { onPlay(c) } }
        override fun getItemCount()=channels.size
    }
}