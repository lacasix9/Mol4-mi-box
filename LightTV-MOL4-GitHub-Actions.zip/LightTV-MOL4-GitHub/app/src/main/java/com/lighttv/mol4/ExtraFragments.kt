package com.lighttv.mol4
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
class RecordingsFragment : Fragment() {
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,b:Bundle?):View{
        val v=i.inflate(R.layout.fragment_settings_mol4,c,false)
        v.findViewById<TextView>(R.id.tv_settings_title).text="RECORDINGS - Comme MyTVOnline4"
        v.findViewById<TextView>(R.id.tv_settings_info).text="Enregistrements:\n- Timeshift 2h activé\n- Dossier: /storage/emulated/0/Movies/LightTV\n- Format: .ts\n\nTouche REC de la télécommande pour enregistrer le live"
        return v
    }
}
class SearchFragment : Fragment() {
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,b:Bundle?):View{
        val v=i.inflate(R.layout.fragment_settings_mol4,c,false)
        v.findViewById<TextView>(R.id.tv_settings_title).text="SEARCH - Recherche comme MOL4"
        v.findViewById<TextView>(R.id.tv_settings_info).text="Recherche dans:\n- Chaînes Live\n- Films VOD\n- Séries\n\nUtilise le clavier virtuel Android TV"
        return v
    }
}