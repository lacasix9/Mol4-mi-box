package com.lighttv.mol4
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
class SettingsFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_settings_mol4, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val prefs = requireContext().getSharedPreferences("lighttv",0)
        view.findViewById<TextView>(R.id.tv_settings_info).text = "Portail: ${prefs.getString("portal_url","")} | User: ${prefs.getString("username","")}\n\nOptions MOL4:\n- Player: Hardware Decoder, Buffer 3s\n- Audio: Piste auto\n- Sous-titres: OFF\n- Aspect Ratio: Auto\n- Parental Control: OFF\n- Timeshift: 2h\n- Enregistrement: /storage"
        view.findViewById<Button>(R.id.btn_edit_portal).setOnClickListener {
            startActivity(android.content.Intent(context, SetupActivity::class.java))
        }
    }
}