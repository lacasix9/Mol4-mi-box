package com.lighttv.mol4
import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.widget.Toast

class AutoUpdateManager(
    private val context: Context,
    private val prefs: SharedPreferences,
    private val xtreamManager: XtreamFullManager,
    private val cacheManager: PlaylistCacheManager
) {
    private val handler = Handler(Looper.getMainLooper())

    // Mise à jour auto au démarrage comme MyTVOnline4
    fun performStartupUpdate(onProgress:(String)->Unit, onComplete:(Boolean)->Unit) {
        Thread {
            try {
                handler.post { onProgress("Chargement cache...") }
                
                // 1. Charge cache si existe pour démarrage instantané
                val hasCache = cacheManager.hasCache()
                
                // 2. Mise à jour en arrière-plan comme MOL4
                handler.post { onProgress("Mise à jour chaînes...") }
                val liveChannels = xtreamManager.getLiveChannels()
                if(liveChannels.isNotEmpty()){
                    cacheManager.saveLiveChannels(liveChannels)
                    val groups = xtreamManager.getLiveGroups()
                    cacheManager.saveGroups(groups)
                    handler.post { onProgress("${liveChannels.size} chaînes mises à jour") }
                }

                handler.post { onProgress("Mise à jour films...") }
                val vod = xtreamManager.getVod()
                if(vod.isNotEmpty()) cacheManager.saveVodMovies(vod)

                handler.post { onProgress("Mise à jour séries...") }
                val series = xtreamManager.getSeries()
                if(series.isNotEmpty()) cacheManager.saveSeries(series)

                handler.post { 
                    Toast.makeText(context, "Playlist mise à jour: ${liveChannels.size} chaînes, ${vod.size} films, ${series.size} séries", Toast.LENGTH_SHORT).show()
                    onComplete(true)
                }

            } catch(e:Exception){
                e.printStackTrace()
                handler.post {
                    Toast.makeText(context, "Erreur mise à jour: ${e.message} - Utilisation cache", Toast.LENGTH_LONG).show()
                    onComplete(false)
                }
            }
        }.start()
    }
}