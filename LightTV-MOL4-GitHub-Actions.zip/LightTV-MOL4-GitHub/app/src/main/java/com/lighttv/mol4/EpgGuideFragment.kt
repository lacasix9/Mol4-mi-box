
package com.lighttv.mol4
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class EpgGuideFragment : Fragment() {
    private lateinit var epgManager: EpgXmlTvManager
    private var epgData: Map<String, List<XmlTvProgram>> = emptyMap()
    private var channels: List<Channel> = emptyList()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_epg_timeline_mol4, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        epgManager = EpgXmlTvManager(requireContext().getSharedPreferences("lighttv",0))
        val rvEpg = view.findViewById<RecyclerView>(R.id.rv_epg_timeline)
        val headerTime = view.findViewById<LinearLayout>(R.id.header_timeline)
        val tvDate = view.findViewById<TextView>(R.id.tv_epg_date)

        tvDate.text = SimpleDateFormat("EEEE dd MMMM - HH:mm", Locale.FRENCH).format(Date())

        // Build time header (like MOL4 Z11)
        val timeFormat = SimpleDateFormat("HH:mm", Locale.FRENCH)
        val startTime = System.currentTimeMillis() - 3600000L // -1h
        val slots = epgManager.getTimelineSlots(startTime, 6)
        headerTime.removeAllViews()
        slots.forEach { time ->
            val tv = TextView(context).apply{
                text = timeFormat.format(Date(time))
                setTextColor(0xFF8A8A9E.toInt())
                textSize = 11f
                setPadding(24,8,24,8)
                layoutParams = LinearLayout.LayoutParams(180, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            headerTime.addView(tv)
        }

        Thread {
            epgData = epgManager.loadXmlTv()
            channels = XtreamFullManager(requireContext().getSharedPreferences("lighttv",0)).getLiveChannels()
            activity?.runOnUiThread {
                rvEpg.layoutManager = LinearLayoutManager(context)
                rvEpg.adapter = EpgTimelineAdapter(channels, epgData, startTime)
            }
        }.start()
    }

    class EpgTimelineAdapter(private val channels: List<Channel>, private val epg: Map<String, List<XmlTvProgram>>, private val startTime:Long): RecyclerView.Adapter<EpgTimelineAdapter.VH>() {
        class VH(v:View): RecyclerView.ViewHolder(v){
            val tvChName = v.findViewById<TextView>(R.id.tv_epg_ch_name)
            val container = v.findViewById<LinearLayout>(R.id.epg_programs_container)
        }
        override fun onCreateViewHolder(p:ViewGroup,t:Int):VH{
            val v=LayoutInflater.from(p.context).inflate(R.layout.item_epg_row_mol4,p,false)
            return VH(v)
        }
        override fun onBindViewHolder(h:VH, pos:Int){
            val ch = channels[pos]
            h.tvChName.text = ch.name
            h.container.removeAllViews()
            // Find programs for this channel (match by name)
            val programs = epg[ch.name] ?: epg.values.firstOrNull() ?: emptyList()
            val now = System.currentTimeMillis()
            programs.forEach { prog ->
                val duration = ((prog.stop - prog.start) / 60000L).toInt() // minutes
                val width = (duration * 3).coerceAtLeast(80) // 3px per minute like MOL4
                val isNow = now in prog.start..prog.stop
                val tv = TextView(h.itemView.context).apply{
                    text = prog.title
                    setTextColor(if(isNow) 0xFFFFFFFF.toInt() else 0xFFCCCCCC.toInt())
                    textSize = 11f
                    maxLines = 2
                    setPadding(12,8,12,8)
                    layoutParams = LinearLayout.LayoutParams(width, 60).apply{ setMargins(2,0,2,0) }
                    setBackgroundResource(if(isNow) R.drawable.bg_epg_now else R.drawable.bg_epg_program)
                }
                h.container.addView(tv)
            }
        }
        override fun getItemCount()=channels.size
    }
}
