package com.lighttv.mol4
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.Fragment
import android.widget.LinearLayout
import android.widget.TextView
import android.view.KeyEvent

class MainActivity : FragmentActivity() {
    private val menuItems = listOf(
        MenuItemMOL4.LIVE to "LIVE TV",
        MenuItemMOL4.VOD to "MOVIES",
        MenuItemMOL4.SERIES to "SERIES",
        MenuItemMOL4.RADIO to "RADIO",
        MenuItemMOL4.EPG to "TV GUIDE",
        MenuItemMOL4.RECORDINGS to "RECORDINGS",
        MenuItemMOL4.SETTINGS to "SETTINGS"
    )
    private var selectedMenu = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_mol4)
        val prefs = getSharedPreferences("lighttv", MODE_PRIVATE)
        if ((prefs.getString("portal_url","") ?: "").isEmpty() && (prefs.getString("m3u_url","") ?: "").isEmpty()) {
            startActivity(Intent(this, SetupActivity::class.java)); finish(); return
        }
        renderMenu()
        loadFragment(LiveTvFragment())
        findViewById<TextView>(R.id.tv_portal_name).text = prefs.getString("portal_name","Portal") ?: "Portal"
    }

    private fun renderMenu() {
        val container = findViewById<LinearLayout>(R.id.menu_container)
        container.removeAllViews()
        menuItems.forEachIndexed { idx, (type, label) ->
            val view = layoutInflater.inflate(R.layout.item_menu_mol4, container, false)
            val tv = view.findViewById<TextView>(R.id.tv_menu)
            tv.text = label
            view.isFocusable = true
            view.isSelected = idx==selectedMenu
            tv.setTextColor(if(idx==selectedMenu) 0xFFFFFFFF.toInt() else 0xFF8A8A9E.toInt())
            view.setBackgroundResource(if(idx==selectedMenu) R.drawable.bg_menu_selected else 0)
            view.setOnFocusChangeListener { v, hasFocus ->
                if(hasFocus){ selectedMenu=idx; renderMenu() }
            }
            view.setOnClickListener {
                selectedMenu=idx; renderMenu()
                when(type){
                    MenuItemMOL4.LIVE -> loadFragment(LiveTvFragment())
                    MenuItemMOL4.VOD -> loadFragment(VodFragment())
                    MenuItemMOL4.SERIES -> loadFragment(SeriesFragment())
                    MenuItemMOL4.EPG -> loadFragment(EpgGuideFragment())
                    MenuItemMOL4.SETTINGS -> loadFragment(SettingsFragment())
                    else -> loadFragment(LiveTvFragment())
                }
            }
            container.addView(view)
        }
    }

    private fun loadFragment(f: Fragment) {
        supportFragmentManager.beginTransaction().replace(R.id.content_container, f).commit()
    }
}