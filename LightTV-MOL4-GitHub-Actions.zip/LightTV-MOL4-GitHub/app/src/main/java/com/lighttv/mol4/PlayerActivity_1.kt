package com.lighttv.mol4
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.ui.PlayerView
class PlayerActivity : FragmentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player_mol4)
        playerView = findViewById(R.id.player_view)
        val url = intent.getStringExtra("url") ?: return
        val name = intent.getStringExtra("name") ?: "Live"
        findViewById<TextView>(R.id.tv_player_title).text = name
        player = ExoPlayer.Builder(this).setSeekBackIncrementMs(10000).setSeekForwardIncrementMs(10000).build().also {
            playerView.player = it
            it.setMediaItem(MediaItem.fromUri(Uri.parse(url)))
            it.prepare(); it.playWhenReady=true
        }
        // Options MOL4: Info bar visible au début
        playerView.showController()
    }
    override fun onKeyDown(keyCode:Int, event:KeyEvent?):Boolean{
        when(keyCode){
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { playerView.showController(); return true }
            KeyEvent.KEYCODE_BACK -> { player?.release(); finish(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }
    override fun onDestroy(){ super.onDestroy(); player?.release() }
}