package com.lighttv.mol4
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class SeriesFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_vod_mol4, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val rv = view.findViewById<RecyclerView>(R.id.rv_vod)
        rv.layoutManager = GridLayoutManager(context, 5)
        view.findViewById<TextView>(R.id.tv_vod_header)?.let { it.text = "SERIES - Choisis une série puis une saison (comme MOL4)" }
        val manager = XtreamFullManager(requireContext().getSharedPreferences("lighttv",0))
        Thread {
            val series = manager.getSeries()
            activity?.runOnUiThread {
                rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                    override fun onCreateViewHolder(p:ViewGroup,t:Int):RecyclerView.ViewHolder{
                        val v=LayoutInflater.from(p.context).inflate(R.layout.item_vod_mol4,p,false); v.isFocusable=true; return object:RecyclerView.ViewHolder(v){}
                    }
                    override fun onBindViewHolder(h:RecyclerView.ViewHolder, pos:Int){
                        val item=series[pos]
                        h.itemView.findViewById<TextView>(R.id.tv_vod_title).text=item.name
                        h.itemView.findViewById<TextView>(R.id.tv_vod_rating).text="${(1..5).random()} Saisons"
                        h.itemView.setOnFocusChangeListener { v,hasFocus -> v.scaleX=if(hasFocus)1.1f else 1f; v.scaleY=if(hasFocus)1.1f else 1f }
                        h.itemView.setOnClickListener {
                            startActivity(Intent(context, SeriesDetailActivity::class.java).apply{
                                putExtra("series_id", item.id); putExtra("series_name", item.name)
                            })
                        }
                    }
                    override fun getItemCount()=series.size
                }
            }
        }.start()
    }
}