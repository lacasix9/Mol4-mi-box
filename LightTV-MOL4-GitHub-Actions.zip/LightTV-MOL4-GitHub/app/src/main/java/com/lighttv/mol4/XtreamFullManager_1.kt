package com.lighttv.mol4
import android.content.SharedPreferences
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit
class XtreamFullManager(private val prefs: SharedPreferences) {
    private val client = OkHttpClient.Builder().connectTimeout(5,TimeUnit.SECONDS).readTimeout(10,TimeUnit.SECONDS).build()
    private fun baseUrl(): String = prefs.getString("portal_url","")!!.trimEnd('/')
    private fun user(): String = prefs.getString("username","")!!
    private fun pass(): String = prefs.getString("password","")!!
    fun getLiveGroups(): List<Group> {
        val m3u = prefs.getString("m3u_url","") ?: ""
        if (m3u.isNotEmpty()) { // parse groups from M3U
            val channels = M3UParser.parseFromUrl(m3u)
            return channels.groupBy { it.group }.map { Group(it.key, it.value.size) }
        }
        try {
            val url = "${baseUrl()}/player_api.php?username=${user()}&password=${pass()}&action=get_live_categories"
            val body = client.newCall(Request.Builder().url(url).build()).execute().body?.string() ?: return mockGroups()
            val arr = JSONArray(body)
            val list = mutableListOf<Group>()
            for(i in 0 until arr.length()){ val o=arr.getJSONObject(i); list.add(Group(o.optString("category_name"),0)) }
            if(list.isNotEmpty()) return list
        } catch(e:Exception){}
        return mockGroups()
    }
    fun getLiveChannels(group: String=""): List<Channel> {
        val m3u = prefs.getString("m3u_url","") ?: ""
        if (m3u.isNotEmpty()) return M3UParser.parseFromUrl(m3u).filter { group.isEmpty() || it.group==group }.mapIndexed { idx, c -> c.copy(num=idx+1, epgNow="Programme ${c.name}", epgProgress=(20..90).random()) }
        try {
            val url = "${baseUrl()}/player_api.php?username=${user()}&password=${pass()}&action=get_live_streams"
            val body = client.newCall(Request.Builder().url(url).build()).execute().body?.string() ?: return mockChannels()
            val arr = JSONArray(body)
            val list = mutableListOf<Channel>()
            for(i in 0 until arr.length()){
                val o=arr.getJSONObject(i)
                list.add(Channel(o.optString("stream_id"), i+1, o.optString("name"), o.optString("stream_icon"), o.optString("category_id"), "${baseUrl()}/live/${user()}/${pass()}/${o.optString("stream_id")}.m3u8", "En cours", "A suivre", (10..90).random()))
            }
            if(list.isNotEmpty()) return list
        } catch(e:Exception){}
        return mockChannels()
    }
    fun getVod(category:String=""): List<VodItem> {
        try {
            val url = "${baseUrl()}/player_api.php?username=${user()}&password=${pass()}&action=get_vod_streams"
            val body = client.newCall(Request.Builder().url(url).build()).execute().body?.string() ?: return mockVod()
            val arr = JSONArray(body)
            val list = mutableListOf<VodItem>()
            for(i in 0 until arr.length().coerceAtMost(50)){
                val o=arr.getJSONObject(i)
                list.add(VodItem(o.optString("stream_id"), o.optString("name"), o.optString("stream_icon"), o.optString("rating","7.5"), "", "", "${baseUrl()}/movie/${user()}/${pass()}/${o.optString("stream_id")}.${o.optString("container_extension","mp4")}", o.optString("plot","")))
            }
            return list
        } catch(e:Exception){ return mockVod() }
    }
    private fun mockGroups() = listOf(Group("All",542), Group("Favorites",12), Group("FRANCE | GENERAL",86), Group("FRANCE | TNT",24), Group("SPORT",45), Group("beIN SPORTS",8), Group("CANAL+",12), Group("CINEMA",32), Group("ENFANTS",18), Group("NEWS",22))
    private fun mockChannels() = listOf(
        Channel("1",1,"TF1 HD","","FRANCE | GENERAL","","20H - Journal","The Voice",65,true,true),
        Channel("2",2,"France 2 HD","","FRANCE | GENERAL","","Envoye Special","Taratata",40,false,true),
        Channel("3",3,"M6 HD","","FRANCE | GENERAL","","Capital","Cauchemar en cuisine",80,false,true),
        Channel("4",4,"beIN SPORTS 1 HD","","SPORT","","Ligue 1: PSG-OM LIVE","Debrief",20,true,true),
        Channel("5",5,"Canal+ Sport HD","","SPORT","","Premier League","Formule 1",55,false,true),
        Channel("6",6,"OCS Max HD","","CINEMA","","Dune 2","Bande-annonce",30,false,true)
    )
    private fun mockVod() = (1..20).map { VodItem("$it","Film $it","", "7.${it%9}","2023","Action","", "Synopsis du film $it - Description complète comme dans MyTVOnline4") }
}
object M3UParser {
    fun parseFromUrl(url:String): List<Channel>{
        return try{ val b=OkHttpClient().newCall(Request.Builder().url(url).build()).execute().body?.string() ?: return emptyList(); parse(b) } catch(e:Exception){ emptyList() }
    }
    fun parse(content:String): List<Channel>{
        val list=mutableListOf<Channel>(); var name=""; var logo=""; var group="FRANCE"; var idx=1
        content.lines().forEach{ l->
            val t=l.trim()
            if(t.startsWith("#EXTINF")){ name=t.substringAfterLast(",").trim(); logo=Regex("tvg-logo=\"([^\"]*)\"").find(t)?.groupValues?.get(1) ?: ""; group=Regex("group-title=\"([^\"]*)\"").find(t)?.groupValues?.get(1) ?: "FRANCE" }
            else if(t.startsWith("http") && name.isNotEmpty()){ list.add(Channel(name.hashCode().toString(), idx++, name, logo, group, t, "Programme en cours", "A suivre", (10..90).random())); name="" }
        }
        return list
    }
}