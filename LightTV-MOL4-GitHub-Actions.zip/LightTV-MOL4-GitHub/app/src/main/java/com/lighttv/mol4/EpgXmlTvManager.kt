
package com.lighttv.mol4
import android.content.SharedPreferences
import okhttp3.OkHttpClient
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

data class XmlTvProgram(val channelId:String, val title:String, val desc:String, val start:Long, val stop:Long)

class EpgXmlTvManager(private val prefs: SharedPreferences) {
    private val client = OkHttpClient.Builder().connectTimeout(10,TimeUnit.SECONDS).readTimeout(20,TimeUnit.SECONDS).build()
    private val dateFormat = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)

    fun loadXmlTv(): Map<String, List<XmlTvProgram>> {
        val xmlUrl = prefs.getString("xmltv_url","") ?: ""
        val xmlContent = when {
            xmlUrl.isNotEmpty() -> try { client.newCall(Request.Builder().url(xmlUrl).build()).execute().body?.string() ?: "" } catch(e:Exception){ "" }
            else -> "" // fallback mock
        }
        return if(xmlContent.isNotEmpty()) parseXmlTv(xmlContent) else mockEpg()
    }

    fun parseXmlTv(xml:String): Map<String, List<XmlTvProgram>> {
        val map = mutableMapOf<String, MutableList<XmlTvProgram>>()
        try {
            val factory = XmlPullParserFactory.newInstance(); factory.isNamespaceAware=false
            val parser = factory.newPullParser(); parser.setInput(StringReader(xml))
            var event = parser.eventType
            var currentChannelId=""
            var currentTitle=""; var currentDesc=""; var currentStart=0L; var currentStop=0L
            while(event != XmlPullParser.END_DOCUMENT){
                when(event){
                    XmlPullParser.START_TAG -> {
                        when(parser.name){
                            "programme" -> {
                                currentChannelId = parser.getAttributeValue(null,"channel") ?: ""
                                currentStart = parseXmlDate(parser.getAttributeValue(null,"start"))
                                currentStop = parseXmlDate(parser.getAttributeValue(null,"stop"))
                            }
                            "title" -> if(parser.next()==XmlPullParser.TEXT) currentTitle=parser.text
                            "desc" -> if(parser.next()==XmlPullParser.TEXT) currentDesc=parser.text
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        if(parser.name=="programme"){
                            val prog = XmlTvProgram(currentChannelId, currentTitle, currentDesc, currentStart, currentStop)
                            map.getOrPut(currentChannelId){ mutableListOf() }.add(prog)
                            currentTitle=""; currentDesc=""
                        }
                    }
                }
                event=parser.next()
            }
        } catch(e:Exception){ e.printStackTrace(); return mockEpg() }
        return map
    }

    private fun parseXmlDate(dateStr:String?): Long {
        return try { dateFormat.parse(dateStr ?: "")?.time ?: System.currentTimeMillis() } catch(e:Exception){ System.currentTimeMillis() }
    }

    private fun mockEpg(): Map<String, List<XmlTvProgram>> {
        val now = System.currentTimeMillis()
        val hour = 3600000L
        val channels = listOf("TF1 HD","France 2","M6","beIN SPORTS 1","Canal+ Sport")
        val map = mutableMapOf<String, MutableList<XmlTvProgram>>()
        channels.forEach { ch ->
            val list = mutableListOf<XmlTvProgram>()
            list.add(XmlTvProgram(ch, "Journal de 20H", "Le journal du soir avec toute l'actualité", now-hour, now+hour/2))
            list.add(XmlTvProgram(ch, "Film: Dune 2", "Film de science-fiction 2024", now+hour/2, now+hour*2))
            list.add(XmlTvProgram(ch, "Late Show", "Talk show", now+hour*2, now+hour*3))
            map[ch]=list
        }
        return map
    }

    // Timeline helpers
    fun getTimelineSlots(startTime:Long, hours:Int=6): List<Long> {
        val slots = mutableListOf<Long>()
        var t = startTime - (startTime % 3600000L)
        repeat(hours*2){ // every 30min
            slots.add(t); t+=1800000L
        }
        return slots
    }
}
