package com.lighttv.mol4
import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

class PlaylistCacheManager(private val context: Context, private val prefs: SharedPreferences) {
    private val gson = Gson()
    private val cacheDir = File(context.filesDir, "playlist_cache").apply { mkdirs() }

    // Fichiers cache comme MyTVOnline4
    private val liveFile = File(cacheDir, "live_channels.json")
    private val vodFile = File(cacheDir, "vod_movies.json")
    private val seriesFile = File(cacheDir, "series.json")
    private val groupsFile = File(cacheDir, "groups.json")
    private val epgFile = File(cacheDir, "epg.xml")

    // Sauvegarde playlist comme MOL4
    fun saveLiveChannels(channels: List<Channel>) {
        try {
            liveFile.writeText(gson.toJson(channels))
            prefs.edit().putLong("last_update_live", System.currentTimeMillis()).apply()
            println("CACHE: Live ${channels.size} chaînes sauvegardées")
        } catch(e:Exception){ e.printStackTrace() }
    }

    fun saveVodMovies(vod: List<VodItem>) {
        try {
            vodFile.writeText(gson.toJson(vod))
            prefs.edit().putLong("last_update_vod", System.currentTimeMillis()).apply()
        } catch(e:Exception){}
    }

    fun saveSeries(series: List<SeriesItem>) {
        try {
            seriesFile.writeText(gson.toJson(series))
            prefs.edit().putLong("last_update_series", System.currentTimeMillis()).apply()
        } catch(e:Exception){}
    }

    fun saveGroups(groups: List<Group>) {
        try { groupsFile.writeText(gson.toJson(groups)) } catch(e:Exception){}
    }

    // Chargement cache instantané comme MOL4 au démarrage
    fun loadLiveChannels(): List<Channel> {
        return try {
            if(!liveFile.exists()) return emptyList()
            val type = object: TypeToken<List<Channel>>(){}.type
            gson.fromJson(liveFile.readText(), type) ?: emptyList()
        } catch(e:Exception){ emptyList() }
    }

    fun loadVodMovies(): List<VodItem> {
        return try {
            if(!vodFile.exists()) return emptyList()
            val type = object: TypeToken<List<VodItem>>(){}.type
            gson.fromJson(vodFile.readText(), type) ?: emptyList()
        } catch(e:Exception){ emptyList() }
    }

    fun loadSeries(): List<SeriesItem> {
        return try {
            if(!seriesFile.exists()) return emptyList()
            val type = object: TypeToken<List<SeriesItem>>(){}.type
            gson.fromJson(seriesFile.readText(), type) ?: emptyList()
        } catch(e:Exception){ emptyList() }
    }

    fun loadGroups(): List<Group> {
        return try {
            if(!groupsFile.exists()) return emptyList()
            val type = object: TypeToken<List<Group>>(){}.type
            gson.fromJson(groupsFile.readText(), type) ?: emptyList()
        } catch(e:Exception){ emptyList() }
    }

    fun hasCache(): Boolean = liveFile.exists() && liveFile.length() > 100

    fun getLastUpdate(): Long = prefs.getLong("last_update_live", 0)

    fun clearCache() {
        liveFile.delete(); vodFile.delete(); seriesFile.delete(); groupsFile.delete()
        prefs.edit().remove("last_update_live").remove("last_update_vod").remove("last_update_series").apply()
    }

    // Vérifie si mise à jour nécessaire (toutes les 6h comme MOL4)
    fun needsUpdate(): Boolean {
        val last = getLastUpdate()
        val sixHours = 6 * 60 * 60 * 1000L
        return System.currentTimeMillis() - last > sixHours
    }
}