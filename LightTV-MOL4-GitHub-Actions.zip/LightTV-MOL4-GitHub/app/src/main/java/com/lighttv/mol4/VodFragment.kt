package com.lighttv.mol4
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView

class VodFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_vod_mol4, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val rv = view.findViewById<RecyclerView>(R.id.rv_vod)
        rv.layoutManager = GridLayoutManager(context, 5)
        val manager = XtreamFullManager(requireContext().getSharedPreferences("lighttv",0))
        Thread {
            val vod = manager.getVod()
            activity?.runOnUiThread {
                rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                    override fun onCreateViewHolder(p:ViewGroup,t:Int):RecyclerView.ViewHolder{
                        val v=LayoutInflater.from(p.context).inflate(R.layout.item_vod_mol4,p,false); v.isFocusable=true; return object:RecyclerView.ViewHolder(v){}
                    }
                    override fun onBindViewHolder(h:RecyclerView.ViewHolder, pos:Int){
                        val item=vod[pos]
                        h.itemView.findViewById<TextView>(R.id.tv_vod_title).text=item.name
                        h.itemView.findViewById<TextView>(R.id.tv_vod_rating).text=item.rating
                        h.itemView.setOnFocusChangeListener { v,hasFocus -> v.scaleX=if(hasFocus)1.1f else 1f; v.scaleY=if(hasFocus)1.1f else 1f }
                        h.itemView.setOnClickListener {
                            startActivity(Intent(context, VodDetailActivity::class.java).apply{
                                putExtra("name", item.name); putExtra("url", item.streamUrl); putExtra("plot", item.plot)
                            })
                        }
                    }
                    override fun getItemCount()=vod.size
                }
            }
        }.start()
    }
}
class SeriesFragment : Fragment() {
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,b:Bundle?):View { return i.inflate(R.layout.fragment_vod_mol4,c,false) }
}
class EpgGuideFragment : Fragment() {
    override fun onCreateView(i:LayoutInflater,c:ViewGroup?,b:Bundle?):View { 
        val v=i.inflate(R.layout.fragment_epg_mol4,c,false)
        v.findViewById<TextView>(R.id.tv_epg_title).text="TV GUIDE - Timeline EPG comme MOL4 (A venir: XMLTV)"
        return v
    }
}