package com.lighttv.mol4
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.FragmentActivity
import com.google.android.exoplayer2.C
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.ui.PlayerView
import com.google.android.exoplayer2.util.MimeTypes

class PlayerActivity : FragmentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var trackSelector: DefaultTrackSelector
    private lateinit var playerView: PlayerView
    private var subtitleUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player_mol4)
        playerView = findViewById(R.id.player_view)
        val url = intent.getStringExtra("url") ?: return
        val name = intent.getStringExtra("name") ?: "Live"
        subtitleUrl = intent.getStringExtra("subtitle_url") // Pour VOD/Séries
        findViewById<TextView>(R.id.tv_player_title).text = name

        trackSelector = DefaultTrackSelector(this).apply{
            setParameters(buildUponParameters().setPreferredTextLanguage("fr").setPreferredAudioLanguage("fr"))
        }

        player = ExoPlayer.Builder(this).setTrackSelector(trackSelector)
            .setSeekBackIncrementMs(10000).setSeekForwardIncrementMs(10000).build().also { exo ->
            playerView.player = exo
            playerView.subtitleView?.visibility = android.view.View.VISIBLE

            // Build MediaItem avec sous-titres comme MyTVOnline4
            val builder = MediaItem.Builder().setUri(Uri.parse(url))

            // 1. Sous-titres externes (SRT/VTT) si fournis par VOD/Série
            if (!subtitleUrl.isNullOrEmpty()) {
                val subConfig = MediaItem.SubtitleConfiguration.Builder(Uri.parse(subtitleUrl))
                    .setMimeType(if(subtitleUrl!!.endsWith(".vtt")) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP)
                    .setLanguage("fr")
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
                builder.setSubtitleConfigurations(listOf(subConfig))
            }

            exo.setMediaItem(builder.build())
            exo.prepare()
            exo.playWhenReady = true
        }

        playerView.showController()
        // Instructions comme MOL4
        Toast.makeText(this, "Touche MENU: Audio/Sous-titres | OK: Contrôles", Toast.LENGTH_LONG).show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when(keyCode){
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { playerView.showController(); return true }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_M -> { showMOL4Options(); return true } // Comme MOL4
            KeyEvent.KEYCODE_CAPTIONS, KeyEvent.KEYCODE_C -> { toggleSubtitles(); return true }
            KeyEvent.KEYCODE_BACK -> { player?.release(); finish(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun showMOL4Options(){
        // Dialog exact MyTVOnline4: Audio, Subtitles, Aspect, Info
        val options = arrayOf("Piste Audio", "Sous-titres", "Ratio d'écran", "Infos EPG", "Favoris")
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog).setTitle("Options comme MyTVOnline4")
            .setItems(options){ _, which ->
                when(which){
                    0 -> showAudioTracks()
                    1 -> showSubtitleTracks()
                    2 -> showAspectRatio()
                }
            }.show()
    }

    private fun showAudioTracks(){
        val tracks = mutableListOf<String>()
        player?.currentTracks?.groups?.forEach { group ->
            if(group.type == C.TRACK_TYPE_AUDIO){
                for(i in 0 until group.length){
                    tracks.add(group.getTrackFormat(i).language ?: "Audio ${i+1}")
                }
            }
        }
        if(tracks.isEmpty()) tracks.addAll(listOf("Français (Auto)", "Anglais", "Original"))
        AlertDialog.Builder(this).setTitle("Piste Audio").setItems(tracks.toTypedArray()){ _, idx ->
            // Sélection audio comme MOL4
            trackSelector.setParameters(trackSelector.buildUponParameters().setPreferredAudioLanguage(if(idx==0) "fr" else "en"))
            Toast.makeText(this, "Audio: ${tracks[idx]}", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun showSubtitleTracks(){
        val options = mutableListOf("Désactivés (OFF)", "Français", "English", "Forcés", "Externe SRT")
        if(!subtitleUrl.isNullOrEmpty()) options[4] = "Externe SRT (Chargé)"
        AlertDialog.Builder(this).setTitle("Sous-titres - Films/Séries").setItems(options.toTypedArray()){ _, idx ->
            when(idx){
                0 -> {
                    trackSelector.setParameters(trackSelector.buildUponParameters().setPreferredTextLanguage(null).setRendererDisabled(C.TRACK_TYPE_TEXT, true))
                    playerView.subtitleView?.visibility = android.view.View.GONE
                    Toast.makeText(this, "Sous-titres: OFF", Toast.LENGTH_SHORT).show()
                }
                1 -> {
                    trackSelector.setParameters(trackSelector.buildUponParameters().setPreferredTextLanguage("fr").setRendererDisabled(C.TRACK_TYPE_TEXT, false))
                    playerView.subtitleView?.visibility = android.view.View.VISIBLE
                    Toast.makeText(this, "Sous-titres: Français", Toast.LENGTH_SHORT).show()
                }
                2 -> {
                    trackSelector.setParameters(trackSelector.buildUponParameters().setPreferredTextLanguage("en").setRendererDisabled(C.TRACK_TYPE_TEXT, false))
                    playerView.subtitleView?.visibility = android.view.View.VISIBLE
                }
                3 -> {
                    trackSelector.setParameters(trackSelector.buildUponParameters().setPreferredTextLanguage("fr").setRendererDisabled(C.TRACK_TYPE_TEXT, false))
                    playerView.subtitleView?.visibility = android.view.View.VISIBLE
                    Toast.makeText(this, "Sous-titres forcés", Toast.LENGTH_SHORT).show()
                }
                4 -> {
                    if(subtitleUrl.isNullOrEmpty()){
                        Toast.makeText(this, "Aucun SRT externe. Place un fichier .srt même nom que la vidéo ou active les pistes intégrées.", Toast.LENGTH_LONG).show()
                    } else {
                        trackSelector.setParameters(trackSelector.buildUponParameters().setRendererDisabled(C.TRACK_TYPE_TEXT, false))
                        Toast.makeText(this, "SRT externe chargé", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }.show()
    }

    private fun showAspectRatio(){
        val ratios = arrayOf("Auto (Défaut MOL4)", "16:9", "4:3", "Zoom", "Plein écran")
        AlertDialog.Builder(this).setTitle("Ratio d'écran").setItems(ratios){ _, idx ->
            playerView.resizeMode = when(idx){
                1 -> com.google.android.exoplayer2.ui.AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                2 -> com.google.android.exoplayer2.ui.AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
                4 -> com.google.android.exoplayer2.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
                else -> com.google.android.exoplayer2.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
        }.show()
    }

    private fun toggleSubtitles(){
        val isDisabled = trackSelector.parameters.getRendererDisabled(C.TRACK_TYPE_TEXT)
        trackSelector.setParameters(trackSelector.buildUponParameters().setRendererDisabled(C.TRACK_TYPE_TEXT, !isDisabled))
        playerView.subtitleView?.visibility = if(isDisabled) android.view.View.VISIBLE else android.view.View.GONE
    }

    override fun onDestroy(){ super.onDestroy(); player?.release(); player=null }
}